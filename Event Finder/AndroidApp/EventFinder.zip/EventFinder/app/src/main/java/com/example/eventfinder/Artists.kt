package com.example.eventfinder

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.eventfinder.com.example.eventfinder.ArtistsAdapter
import org.json.JSONArray
import org.json.JSONObject


class Artists : Fragment() {
    private lateinit var artistArray: List<String>
    private lateinit var progressBar: ProgressBar
    private lateinit var adapter: ArtistsAdapter
    private lateinit var requestQueue: RequestQueue
    private lateinit var noArtistsCard: CardView
    private lateinit var artistScroll: ScrollView
    private lateinit var loading: RelativeLayout
    private lateinit var artistRecycler: RecyclerView
    private val backend_url = "http://hw8-env.eba-hwjhcppp.us-east-1.elasticbeanstalk.com/"

    private val artistData = mutableListOf<JSONObject>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestQueue = Volley.newRequestQueue(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // get bundle
        artistArray = requireArguments().getStringArrayList("artistArray") as List<String>
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_artists, container, false)

        // Fields
        loading = view.findViewById(R.id.loadingDetails)
        loading.visibility = View.VISIBLE

        progressBar = view.findViewById(R.id.artist_progressbar)
        progressBar.visibility = View.VISIBLE

        noArtistsCard = view.findViewById(R.id.no_artists)
        noArtistsCard.visibility = View.GONE

        artistScroll = view.findViewById(R.id.artistLayout)
        artistScroll.visibility = View.GONE

        artistRecycler = view.findViewById(R.id.artistsRecycler)

        // Set up the RecyclerView and its adapter
        adapter = ArtistsAdapter()
        artistRecycler.layoutManager = LinearLayoutManager(context)
        artistRecycler.adapter = adapter

        Log.v("artistarray",artistArray.toString())
        if(artistArray.isEmpty()) {
            progressBar.visibility = View.GONE
            noArtistsCard.visibility = View.VISIBLE
        }
        else {
            // Load data from server
            for (i in artistArray.indices) {
                Log.v("iter", artistArray.reversed()[i])
                getArtistDetails(artistArray.reversed()[i])
            }


        }



        return view
    }

    private fun getArtistDetails(name: String) {
        // Perform network request in a background thread
        // Once the data has been loaded, update the adapter and hide the progress bar
        // Check if location permissions are granted
        val params = "artist=$name"
        val url = backend_url + "searchArtist?" + params
        val request = JsonObjectRequest(url,
            { response ->
//                Log.v("result", response.toString())
                artistData.add(response)
                if(artistData.size == artistArray.size) {
                    val list = JSONArray(artistData)
                    adapter.setData(list!!)
                    loading.visibility = View.GONE
                    artistScroll.visibility = View.VISIBLE
                }






            },
            { error ->
                loading.visibility = View.GONE
                artistScroll.visibility = View.VISIBLE
                Toast.makeText(requireContext(), "Search failed: ${error.message}", Toast.LENGTH_SHORT).show()
            })
        requestQueue.add(request)


    }


}