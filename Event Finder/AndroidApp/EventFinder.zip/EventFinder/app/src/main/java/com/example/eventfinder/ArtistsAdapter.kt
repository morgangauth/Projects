package com.example.eventfinder.com.example.eventfinder

import android.content.Intent
import android.graphics.Paint
import android.net.Uri
import android.text.Html
import android.text.method.LinkMovementMethod
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.core.text.HtmlCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.eventfinder.R
import com.example.eventfinder.RoundedTransformation
import com.squareup.picasso.Picasso
import org.json.JSONArray
import org.json.JSONObject
import java.text.DecimalFormat


class ArtistsAdapter : RecyclerView.Adapter<ArtistsAdapter.MyViewHolder>() {

    private val dataList = mutableListOf<JSONObject>()

    fun setData(newList: JSONArray) {
        dataList.clear()
        for (i in 0 until newList.length()) {
            val item = newList.getJSONObject(i)
            dataList.add(0,item)
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.artist_item_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(dataList[position])

    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val artistImage: ImageView = itemView.findViewById(R.id.artistImage)
        private val name: TextView = itemView.findViewById(R.id.artistName)
        private val followers: TextView = itemView.findViewById(R.id.followers)
        private val spotifyLink: TextView = itemView.findViewById(R.id.spotifyLink)
        private val popText: TextView = itemView.findViewById(R.id.progress_text)
        private val popularity: ProgressBar = itemView.findViewById(R.id.popularity)

        //albums
        private val album1: ImageView = itemView.findViewById(R.id.album1)
        private val album2: ImageView = itemView.findViewById(R.id.album2)
        private val album3: ImageView = itemView.findViewById(R.id.album3)

        fun bind(myData: JSONObject) {
            // Bind data to views here
            Log.v("recycler",myData.toString())
            // image
            val artistData = myData.getJSONObject("artist")
            val albumData = myData.getJSONObject("albums")
            val imageUrl = artistData.getJSONArray("images").getJSONObject(2).getString("url")
            Picasso.get().load(imageUrl).into(artistImage)
            //name
            name.text = artistData.getString("name")
            name.isSelected = true
            //pop
            popText.text = artistData.getString("popularity")
            popularity.progress = artistData.getString("popularity").toInt()
            // followers
            val followerNum = artistData.getJSONObject("followers").getString("total")
            followers.text = "${formatNumber(followerNum.toInt())} Followers"

            // link
            spotifyLink.paintFlags = Paint.UNDERLINE_TEXT_FLAG
            spotifyLink.setOnClickListener {
                val spotifyUrl = artistData.getJSONObject("external_urls").getString("spotify")
                val intent = Intent(Intent.ACTION_VIEW)
                intent.data = Uri.parse(spotifyUrl)
                startActivity(itemView.context, intent, null)

            }

            // albums
            val albumUrl1 = albumData.optJSONArray("items")?.optJSONObject(0)?.optJSONArray("images")?.optJSONObject(1)?.optString("url")
            if(albumUrl1 != null) {
                Picasso.get().load(albumUrl1).transform(RoundedTransformation(20, 0)).into(album1)
            }
            else {
                album1.visibility = View.GONE
            }
            val albumUrl2 = albumData.optJSONArray("items")?.optJSONObject(1)?.optJSONArray("images")?.optJSONObject(1)?.optString("url")
            if(albumUrl2 != null) {
                Picasso.get().load(albumUrl2).transform(RoundedTransformation(20, 0)).into(album2)
            }
            else {
                album2.visibility = View.GONE
            }
            val albumUrl3 = albumData.optJSONArray("items")?.optJSONObject(2)?.optJSONArray("images")?.optJSONObject(1)?.optString("url")
            if(albumUrl3 != null) {
                Picasso.get().load(albumUrl3).transform(RoundedTransformation(20, 0)).into(album3)
            }
            else {
                album3.visibility = View.GONE
            }



        }

        private fun formatNumber(number: Int): String {
            val suffixes = arrayOf("", "K", "M", "B", "T") // Define the suffixes
            val df = DecimalFormat("###") // Define the format
            var index = 0
            var num = number.toDouble()
            while (num >= 1000.0 && index < suffixes.size - 1) {
                num /= 1000.0
                index++
            }
            return df.format(num) + suffixes[index] // Add the suffix to the formatted number
        }
    }
}
