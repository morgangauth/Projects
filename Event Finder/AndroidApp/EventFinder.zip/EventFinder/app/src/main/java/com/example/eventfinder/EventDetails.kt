package com.example.eventfinder

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.text.util.Linkify
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.core.util.Predicate
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.squareup.picasso.Picasso
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*


class EventDetails : Fragment() {

    private lateinit var eventId: String

    private lateinit var loading: RelativeLayout
    private lateinit var results: LinearLayout
    // Fields
    private lateinit var artistTeam: TextView
    private lateinit var venue: TextView
    private lateinit var date: TextView
    private lateinit var time: TextView
    private lateinit var genres: TextView
    private lateinit var priceRange: TextView
    private lateinit var ticketStatusText: TextView
    private lateinit var buyTicketsUrl: TextView
    private lateinit var ticketStatusCard: CardView
    private lateinit var seatmap: ImageView

    private lateinit var requestQueue: RequestQueue
    private val backend_url = "http://hw8-env.eba-hwjhcppp.us-east-1.elasticbeanstalk.com/"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestQueue = Volley.newRequestQueue(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // get bundle
        eventId = requireArguments().getString("eventId", "")
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_details, container, false)

        loading = view.findViewById(R.id.loadingDetails)
        loading.visibility = View.VISIBLE
        results = view.findViewById(R.id.detailsLayout)
        results.visibility = View.GONE

        // Fields
        artistTeam = view.findViewById(R.id.artistTeams)
        venue = view.findViewById(R.id.venue)
        date = view.findViewById(R.id.date)
        time = view.findViewById(R.id.time)
        genres = view.findViewById(R.id.genres)
        priceRange = view.findViewById(R.id.price)
        ticketStatusText = view.findViewById(R.id.ticketStatusText)
        buyTicketsUrl = view.findViewById(R.id.buyTickets)
        ticketStatusCard = view.findViewById(R.id.ticketStatusCard)
        seatmap = view.findViewById(R.id.seatmap)

        // Load data from server
        getEventDetails()


        return view
    }

    private fun getEventDetails() {
        // Perform network request in a background thread
        // Once the data has been loaded, update the adapter and hide the progress bar
        // Check if location permissions are granted
        val params = "eventId=$eventId"
        val url = backend_url + "searchEvents?" + params
        val request = JsonObjectRequest(url,
            { response ->
                Log.v("result", response.toString())
                loading.visibility = View.GONE
                results.visibility = View.VISIBLE
                //handle results
                //artist
                val artists = response.optJSONObject("_embedded")?.optJSONArray("attractions")
                var artistList = mutableListOf<String>()
                if (artists != null) {
                    for (i in 0 until artists.length()) {
                        val item = artists.getJSONObject(i)
                        artistList.add(item.getString("name"))
                    }
                }
                Log.v("test",artistList.toString())
                artistTeam.text = artistList.joinToString(" | ")
                artistTeam.isSelected = true


                //venue
                venue.text = response.getJSONObject("_embedded").getJSONArray("venues").getJSONObject(0).getString("name")
                venue.isSelected = true

                //date
                val dateString = response.getJSONObject("dates").getJSONObject("start").getString("localDate")
                val srcFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val dateObj = srcFormat.parse(dateString)
                val targetFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                date.text = dateObj?.let { targetFormat.format(it).toString() }
                //time
                time.text = if(response.getJSONObject("dates").getJSONObject("start").getString("noSpecificTime") == "true") {
                    "-"} else {
                    val inputFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                    val outputFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
                    val timeString = response.getJSONObject("dates").getJSONObject("start").getString("localTime")
                    inputFormat.parse(timeString)?.let { outputFormat.format(it).toString() }
                }
                //genres
                val genresData = response.getJSONArray("classifications").getJSONObject(0)
                var genreList = mutableListOf<String>()
                genresData.optJSONObject("segment")?.optString("name")?.let { genreList.add(it) }
                genresData.optJSONObject("genre")?.optString("name")?.let { genreList.add(it) }
                genresData.optJSONObject("subGenre")?.optString("name")?.let { genreList.add(it) }
                genresData.optJSONObject("type")?.optString("name")?.let { genreList.add(it) }
                genresData.optJSONObject("subType")?.optString("name")?.let { genreList.add(it) }

                genreList.removeIf { it == "Undefined" }
                genres.text = genreList.joinToString(" | ")

                genres.isSelected = true

                //price ranges
                val range = response.optJSONArray("priceRanges")?.optJSONObject(0)
                if(range != null) {
                    priceRange.text =
                        "${range.getString("min")} - ${range.getString("max")} (${range.getString("currency")})"
                    priceRange.isSelected = true
                }
                else {
                    priceRange.visibility = View.GONE

                }


                //ticket status
                val ticketStatusVal = response.getJSONObject("dates").getJSONObject("status").getString("code")
                ticketStatusCard.setCardBackgroundColor(when (ticketStatusVal) {
                    "onsale" -> Color.GREEN
                    "offsale" -> Color.RED
                    "cancelled" -> Color.BLACK
                    "postponed" -> Color.YELLOW
                    "rescheduled" -> Color.YELLOW
                    else -> Color.WHITE
                })

                ticketStatusText.text = when (ticketStatusVal) {
                    "onsale" -> "On Sale"
                    "offsale" -> "Off Sale"
                    "cancelled" -> "Cancelled"
                    "postponed" -> "Postponed"
                    "rescheduled" -> "Rescheduled"
                    else -> "N/A"
                }




                //buy
                buyTicketsUrl.text = response.getString("url")
                buyTicketsUrl.isSelected = true
//                buyTicketsUrl.movementMethod = LinkMovementMethod.getInstance()



//                val linkColor = ContextCompat.getColor(requireContext(), R.color.green)
//                val linkColorStateList = ColorStateList(
//                    arrayOf(
//                        intArrayOf(android.R.attr.state_pressed),
//                        intArrayOf(android.R.attr.state_selected),
//                        intArrayOf(android.R.attr.state_focused),
//                        intArrayOf(-android.R.attr.state_pressed, -android.R.attr.state_selected)
//                    ),
//                    intArrayOf(
//                        linkColor,
//                        linkColor,
//                        linkColor,
//                        linkColor
//                    )
//                )
//                buyTicketsUrl.setTextColor(linkColorStateList)
//                buyTicketsUrl.setLinkTextColor(linkColorStateList)

                //seatmap
                val imageUrl = response.optJSONObject("seatmap")?.optString("staticUrl")
                if(imageUrl != null) {Picasso.get().load(imageUrl).into(seatmap)}
            },
            { error ->
                loading.visibility = View.GONE
                results.visibility = View.VISIBLE
                Toast.makeText(requireContext(), "Search failed: ${error.message}", Toast.LENGTH_SHORT).show()
            })
        requestQueue.add(request)


    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Details.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            EventDetails().apply {
                arguments = Bundle().apply {
                }
            }
    }
}