package com.example.eventfinder

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.eventfinder.databinding.ActivityEventDetailsBinding
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.MapsInitializer.Renderer
import com.google.android.gms.maps.OnMapsSdkInitializedCallback
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import org.json.JSONObject


val detailsTabArray = arrayOf(
    "Details", "Artist(s)", "Venue"
)
val iconsArray = arrayOf(
    R.drawable.info_icon,
    R.drawable.artist_icon,
    R.drawable.venue_icon
)

class EventDetailsActivity : AppCompatActivity(), OnMapsSdkInitializedCallback  {
    private lateinit var binding: ActivityEventDetailsBinding
    private lateinit var tabLayout: TabLayout
    private lateinit var eventId: String
    private lateinit var venueId: String
    private lateinit var eventName: String
    private lateinit var eventUrl: String
    private lateinit var eventBlob: String
    private lateinit var artistArray: List<String>
    private lateinit var sharedpreferences: SharedPreferences
    private lateinit var favoriteIds:  MutableSet<String>
    private lateinit var favoritesData:  MutableSet<String>
    private lateinit var favoritesMenuItem:  MenuItem

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_EventFinder_NoActionBar)
        super.onCreate(savedInstanceState)
        MapsInitializer.initialize(applicationContext, Renderer.LATEST, this)

        binding = ActivityEventDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        eventId = intent.getStringExtra("event_id").toString()
        eventName = intent.getStringExtra("event_name").toString()
        eventUrl = intent.getStringExtra("event_url").toString()
        venueId = intent.getStringExtra("venue_id").toString()
        eventBlob = intent.getStringExtra("eventBlob").toString()
        artistArray = intent.getStringArrayListExtra("artist_array")?.toList() as List<String>
        Log.v("activity artist array", artistArray.toString())

        sharedpreferences = getSharedPreferences("favorites",
            Context.MODE_PRIVATE);
        favoriteIds = sharedpreferences.getStringSet("favoriteIds", mutableSetOf())!!

        val viewPager = binding.eventDetailsViewPager
        val toolbar = binding.eventDetailsToolbar
        val toolbarTitle = findViewById<TextView>(R.id.toolbar_title)
        toolbarTitle.text = eventName
        toolbarTitle.isSelected = true
        toolbar.inflateMenu(R.menu.event_details_menu)
        toolbar.setNavigationIcon(R.drawable.ic_baseline_arrow_back_24)
        toolbar.navigationIcon?.setTint(ContextCompat.getColor(this, R.color.green))
        toolbar.setNavigationOnClickListener {
            // Handle navigation icon click here
            

        }
        setSupportActionBar(toolbar)
//        toolbar.setHomeButtonEnabled(true)
        tabLayout = binding.eventDetailsTabLayout

        val adapter = EventDetailsViewPagerAdapter(supportFragmentManager, lifecycle, eventId, venueId, artistArray)
        viewPager.adapter = adapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = detailsTabArray[position]
        }.attach()
        setupTabIcons()

    }
    private fun setupTabIcons() {
        tabLayout.getTabAt(0)?.setIcon(iconsArray[0])
        tabLayout.getTabAt(1)?.setIcon(iconsArray[1])
        tabLayout.getTabAt(2)?.setIcon(iconsArray[2])
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.event_details_menu, menu)
        favoritesMenuItem = menu.findItem(R.id.favorite_button)
        if(favoriteIds.contains(eventId)) {
            favoritesMenuItem.setIcon(R.drawable.heart_filled)
        }
        else {
            favoritesMenuItem.setIcon(R.drawable.heart_outline)
        }

        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.facebook_button -> {
                val openURL = Intent(Intent.ACTION_VIEW)
                openURL.data = Uri.parse("https://www.facebook.com/sharer/sharer.php?u=$eventUrl&amp;src=sdkpreparse")
                startActivity(openURL)
                true
            }
            R.id.twitter_button -> {
                val openURL = Intent(Intent.ACTION_VIEW)
                openURL.data = Uri.parse("https://twitter.com/intent/tweet?text=Check $eventName on Ticketmaster! $eventUrl")
                startActivity(openURL)
                true
            }
            R.id.favorite_button -> {
                val editor: SharedPreferences.Editor = sharedpreferences.edit()
                favoriteIds = sharedpreferences.getStringSet("favoriteIds", mutableSetOf())!!
                favoritesData = sharedpreferences.getStringSet("favoritesData", mutableSetOf())!!
                if(favoriteIds.contains(eventId)) {
                    // remove from favorites
                    favoriteIds.remove(eventId)
                    editor.putStringSet("favoriteIds", favoriteIds)
                    for (i in 0 until  favoritesData.size) {
                        val js = JSONObject(favoritesData.toList()[i])
                        if(js.getString("id") == eventId) {
                            favoritesData.remove(js.toString())
                            break
                        }
                    }
                    editor.putStringSet("favoritesData", favoritesData)
                    editor.commit()
                    favoritesMenuItem.setIcon(R.drawable.heart_outline)
                    Toast.makeText(applicationContext, "$eventName removed from favorites", Toast.LENGTH_SHORT).show()
                }
                else {
                    //add to favorites
                    favoriteIds.add(eventId)
                    editor.putStringSet("favoriteIds", favoriteIds)
                    favoritesData.add(eventBlob)
                    editor.putStringSet("favoritesData", favoritesData)

                    editor.commit()
                    favoritesMenuItem.setIcon(R.drawable.heart_filled)
                    Toast.makeText(applicationContext, "$eventName added to favorites", Toast.LENGTH_SHORT).show()
                }


                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onMapsSdkInitialized(renderer: MapsInitializer.Renderer) {
        when (renderer) {
            Renderer.LATEST -> Log.d("MapsDemo", "The latest version of the renderer is used.")
            Renderer.LEGACY -> Log.d("MapsDemo", "The legacy version of the renderer is used.")
        }
    }

}

    // references:
//    https://stackoverflow.com/questions/37833495/add-iconstext-to-tablayout