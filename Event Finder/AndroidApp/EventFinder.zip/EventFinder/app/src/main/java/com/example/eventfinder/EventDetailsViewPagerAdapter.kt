package com.example.eventfinder

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.viewpager2.adapter.FragmentStateAdapter

private const val NUM_TABS = 3

public class EventDetailsViewPagerAdapter(fragmentManager: FragmentManager, lifecycle: Lifecycle, eventId: String, venueId: String, artistArray: List<String>) :
    FragmentStateAdapter(fragmentManager, lifecycle) {

    private val eventId = eventId;
    private val venueId = venueId;
    private val artistArray = artistArray;

    override fun getItemCount(): Int {
        return NUM_TABS
    }

    override fun createFragment(position: Int): Fragment {
        when (position) {
            0 -> return EventDetails().apply {
                arguments = Bundle().apply {
                    putString("eventId", eventId)
                }
            }
            1 -> return Artists().apply {
                arguments = Bundle().apply {
                    putStringArrayList("artistArray", ArrayList(artistArray))
                }
            }
            2 -> return Venue().apply {
                arguments = Bundle().apply {
                    putString("venueId", venueId)
                }
            }
        }
        return EventDetails()
    }
}