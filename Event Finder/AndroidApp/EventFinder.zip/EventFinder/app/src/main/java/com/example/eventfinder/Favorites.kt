package com.example.eventfinder

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.ScrollView
import androidx.cardview.widget.CardView
import androidx.core.os.bundleOf
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject


/**
 * A simple [Fragment] subclass.
 * Use the [Favorites.newInstance] factory method to
 * create an instance of this fragment.
 */
class Favorites : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var adapter: ResultsAdapter
    private lateinit var noFavesCard: CardView
    private lateinit var favoritesScroll: ScrollView
    private lateinit var searching: RelativeLayout
    private lateinit var sharedPreferences: SharedPreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedPreferences = requireActivity().getSharedPreferences("favorites",
            Context.MODE_PRIVATE);

        // Define a listener for changes to the preference
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { prefs, key ->
            // Update the data source for the RecyclerView adapter here
        }

// Register the listener
        sharedPreferences.registerOnSharedPreferenceChangeListener(listener)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        refreshFaves()

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_favorites, container, false)
        recyclerView = view.findViewById(R.id.favoritesRecycler)
        progressBar = view.findViewById(R.id.favoritesProgress)
        progressBar.visibility = View.VISIBLE
        noFavesCard = view.findViewById(R.id.no_faves_found)
        noFavesCard.visibility = View.GONE
        favoritesScroll = view.findViewById(R.id.favorites_scroll)
        favoritesScroll.visibility = View.GONE
        searching = view.findViewById(R.id.searching)
        searching.visibility = View.VISIBLE

        // Set up the RecyclerView and its adapter
        adapter = ResultsAdapter(requireActivity(), this)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter

//        val listener = SharedPreferences.OnSharedPreferenceChangeListener { sharedPreferences, key ->
//            // Handle the change here
//            refreshFaves()
//        }
//        sharedPreferences.registerOnSharedPreferenceChangeListener(listener)

        return view
    }

    fun refreshFaves() {
        sharedPreferences = requireActivity().getSharedPreferences("favorites",
            Context.MODE_PRIVATE);
        var favoriteIds = sharedPreferences.getStringSet("favoriteIds", mutableSetOf())!!
        Log.v("favoriteIds", favoriteIds.toString())
        if(favoriteIds.isEmpty()) {
            //no favorites
            searching.visibility = View.VISIBLE
            progressBar.visibility = View.GONE
            noFavesCard.visibility = View.VISIBLE
        }
        else {

            var favoritesData = sharedPreferences.getStringSet("favoritesData", mutableSetOf())!!

            val jsonArray = JSONArray()
            favoritesData.forEach { value ->
                jsonArray.put( JSONObject(value))
            }
            adapter.setData(jsonArray!!, sharedPreferences)
            favoritesScroll.visibility = View.VISIBLE
            searching.visibility = View.GONE
        }

    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Favorites.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance() =
            Favorites().apply {
                arguments = Bundle().apply {
                }
            }
    }
}