package com.example.eventfinder

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.NavHostFragment
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class ResultsAdapter(private val context: Context, private val fragment: Favorites?) : RecyclerView.Adapter<ResultsAdapter.MyViewHolder>() {
    private val dataList = mutableListOf<JSONObject>()
    private lateinit var favoriteIds:  MutableSet<String>
    private lateinit var favoritesData:  MutableSet<String>
    private lateinit var adapterSharedPreferences: SharedPreferences

    fun setData(newList: JSONArray, sharedPreferences: SharedPreferences) {
        dataList.clear()
        // Get a value from the shared preferences
        adapterSharedPreferences = sharedPreferences
        favoriteIds = sharedPreferences.getStringSet("favoriteIds", mutableSetOf())!!
        favoritesData = sharedPreferences.getStringSet("favoritesData", mutableSetOf())!!
        for (i in 0 until newList.length()) {
            val item = newList.getJSONObject(i)
            dataList.add(item)
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.result_item, parent, false)
        return MyViewHolder(view, favoriteIds, adapterSharedPreferences, favoritesData, context, this, fragment)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(dataList[position])

        holder.itemView.setOnClickListener {
            // Start a new activity when the item is clicked
            val intent = Intent(holder.itemView.context, EventDetailsActivity::class.java)
            // event ID
            intent.putExtra("event_id", dataList[position].getString("id"))
            // event name
            intent.putExtra("event_name", dataList[position].getString("name"))
            // event URL
            intent.putExtra("event_url", dataList[position].getString("url"))
            // Venue ID
            intent.putExtra("venue_id", dataList[position].getJSONObject("_embedded").getJSONArray("venues").getJSONObject(0).getString("id"))
            // Artists
            val artistArray = dataList[position].optJSONObject("_embedded")?.optJSONArray("attractions")
            val artistNameArray = mutableListOf<String>()
            if (artistArray != null) {
                for (i in 0 until artistArray.length()) {
                    val jsonObject = artistArray.getJSONObject(i)
                    if(jsonObject.getJSONArray("classifications").getJSONObject(0).getJSONObject("segment").getString("name") == "Music") {
                        artistNameArray.add(jsonObject.getString("name"))
                    }
                }
            }
            Log.v("Adapter Artist Array", artistNameArray.toString())

            intent.putStringArrayListExtra("artist_array",ArrayList(artistNameArray))
            // blob for favorites
            intent.putExtra("eventBlob", dataList[position].toString())
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    class MyViewHolder(itemView: View, favoriteIds: MutableSet<String>, sharedPreferences: SharedPreferences, favoritesData: MutableSet<String>, activityContext:Context, radapter: ResultsAdapter, fragmentParam: Favorites?) : RecyclerView.ViewHolder(itemView) {
        private val imageField: ImageView = itemView.findViewById(R.id.resultImage)
        private val name: TextView = itemView.findViewById(R.id.resultName)
        private val venue: TextView = itemView.findViewById(R.id.resultVenue)
        private val cat: TextView = itemView.findViewById(R.id.resultCat)
        private val date: TextView = itemView.findViewById(R.id.resultDate)
        private val time: TextView = itemView.findViewById(R.id.resultTime)
        private val favorite: ImageView = itemView.findViewById(R.id.resultHeart)
        private var favoriteIdSet: MutableSet<String> = favoriteIds
        private val sharedPreferencesHolder: SharedPreferences = sharedPreferences
        private var favoritesArray: MutableSet<String> = favoritesData
        private var fragment: Favorites? = fragmentParam
        private var context: Context = activityContext
        private val adapter: ResultsAdapter = radapter

        fun bind(myData: JSONObject) {
            // Bind data to views here
            // image
            val imageUrl = myData.getJSONArray("images").getJSONObject(0).getString("url")
            Picasso.get().load(imageUrl).transform(RoundedTransformation(20, 0)).into(imageField)
//            imageField.setImageResource(R.drawable.round_button);
            //title
            name.text = myData.getString("name")
            name.isSelected = true
            //cat
            cat.text = myData.getJSONArray("classifications").getJSONObject(0).getJSONObject("segment").getString("name")
            //venue
            venue.text = myData.getJSONObject("_embedded").getJSONArray("venues").getJSONObject(0).getString("name")
            venue.isSelected = true
            //date
            val dateString = myData.getJSONObject("dates").getJSONObject("start").getString("localDate")
            val srcFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val dateObj = srcFormat.parse(dateString)
            val targetFormat = SimpleDateFormat("MM/dd/yyyy", Locale.getDefault())
            date.text = dateObj?.let { targetFormat.format(it).toString() }
            //time
            time.text = if(myData.getJSONObject("dates").getJSONObject("start").getString("noSpecificTime") == "true") {
                "-"} else {
                val inputFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                val outputFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
                val timeString = myData.getJSONObject("dates").getJSONObject("start").getString("localTime")
                inputFormat.parse(timeString)?.let { outputFormat.format(it).toString() }
                }

            //favorite
            if(favoriteIdSet.contains(myData.getString("id"))) {
                favorite.setImageResource(R.drawable.heart_filled)
            }
            else {
                favorite.setImageResource(R.drawable.heart_outline)
            }

            favorite.setOnClickListener{
                val editor: SharedPreferences.Editor = sharedPreferencesHolder.edit()
                if(favoriteIdSet.contains(myData.getString("id"))) {
                    // remove from favorites
                    favoriteIdSet.remove(myData.getString("id"))
                    editor.putStringSet("favoriteIds", favoriteIdSet)
                    Log.v("count", favoritesArray.count().toString())
                    for (i in 0 until  favoritesArray.size) {
                        val js = JSONObject(favoritesArray.toList()[i])
                        if(js.getString("id") == myData.getString("id")) {
                            favoritesArray.remove(js.toString())
                            break
                        }
                    }
//                    favoritesArray = favoritesArray.filter { !it.contains("\"id\": \"${myData.getString("id")}\",") }.toMutableSet()
                    Log.v("count2", favoritesArray.count().toString())
                    editor.putStringSet("favoritesData", favoritesArray)
                    editor.commit()
                    favorite.setImageResource(R.drawable.heart_outline)
                    Toast.makeText(itemView.context, "${myData.getString("name")} removed from favorites", Toast.LENGTH_SHORT).show()
                }
                else {
                    //add to favorites
                    favoriteIdSet.add(myData.getString("id"))
                    editor.putStringSet("favoriteIds", favoriteIdSet)
                    favoritesArray.add(myData.toString())
                    editor.putStringSet("favoritesData", favoritesArray)
//                    var eventToAdd = """{
//                        "id": ${myData.getString("id")},
//                        "name" : ${myData.getString("name")},
//                        "imageUrl" : $imageUrl,
//                        "venue" : ${venue.text},
//                        "category":
//
//                    }"""

                    editor.commit()
                    favorite.setImageResource(R.drawable.heart_filled)
                    Toast.makeText(itemView.context, "${myData.getString("name")} added to favorites", Toast.LENGTH_SHORT).show()
                }

                adapter.notifyDataSetChanged()

                val activity = context as MainActivity
                fragment = activity.supportFragmentManager.findFragmentByTag("f1") as Favorites?
                fragment?.refreshFaves()
//
                val navHostFragment = activity.supportFragmentManager.findFragmentByTag("f0")?.childFragmentManager?.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
                var myFragment = navHostFragment.childFragmentManager.fragments[0]
                if (myFragment.javaClass.simpleName == "SearchResults") {
                    myFragment = myFragment as SearchResults?
                    myFragment?.refreshAdapter()
                }


//                Log.v("searchresultfrag", navHostFragment.childFragmentManager.fragments[0].id.toString())

            }

        }
    }
}
