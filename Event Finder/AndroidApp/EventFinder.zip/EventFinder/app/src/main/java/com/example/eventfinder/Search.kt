package com.example.eventfinder

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.navigation.Navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.snackbar.Snackbar


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val DEFAULT_DISTANCE = "10"
private const val ARG_PARAM2 = "param2"




/**
 * A simple [Fragment] subclass.
 * Use the [Search.newInstance] factory method to
 * create an instance of this fragment.
 * Note: AutoComplete implemented with help from ChatGPT
 */
class Search : Fragment() {
    //bundle val
    private var keywordVal = ""
    var autoLocVal = false
    var distVal = ""
    var catVal = ""
    var locVal = ""


    //fields
    private lateinit var spinner: Spinner
    private lateinit var autoLocation: Switch
    private lateinit var distField: EditText
    private lateinit var snackbar: Snackbar
    private lateinit var keyword: AutoCompleteTextView
    private lateinit var locationField: EditText
    private lateinit var autoProgressBar: ProgressBar

    private lateinit var requestQueue: RequestQueue


    val backend_url = "http://hw8-env.eba-hwjhcppp.us-east-1.elasticbeanstalk.com/"
    var selectedCat = "Default"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestQueue = Volley.newRequestQueue(requireContext())
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // set views and default dist value
        keyword = view.findViewById(R.id.autoCompleteTextView)
        keyword.setText(keywordVal)
        Log.v("keyword",keywordVal)

        distField = view.findViewById(R.id.distance)
        distField.setText(distVal)

        spinner = view.findViewById<Spinner>(R.id.categorySpinner)

        autoLocation = view.findViewById(R.id.autoLocation)
        autoLocation.isChecked = autoLocVal

        locationField = view.findViewById(R.id.location)
        if(autoLocation.isChecked) {
            locationField.visibility = View.GONE
        }
        else {
            locationField.setText(locVal)
        }
        autoProgressBar = view.findViewById(R.id.autoCompleteProgressBar)
        autoProgressBar.visibility = View.GONE

        // Auto-Location behavior
        autoLocation.setOnCheckedChangeListener { _, isChecked ->
            // Handle switch toggle event here
            if (isChecked) {
                // Do something when switch is checked
                locationField.visibility = View.GONE

            } else {
                // Do something when switch is unchecked
                locationField.visibility = View.VISIBLE
            }
        }
// Category Dropdown Behavior
        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.categories_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            spinner.adapter = adapter
            if(catVal == "Default") {
                spinner.setSelection(0)
            }
            else {
                spinner.setSelection(resources.getStringArray(R.array.categories_array).indexOf(catVal))
            }
        }
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                // Handle spinner item selection here
                if(view != null && view is TextView) {
                    view.setTextColor(Color.WHITE)
                }
                (parent.getChildAt(0) as TextView?)?.setTextColor(Color.WHITE)

                selectedCat = if(parent.getItemAtPosition(position).toString() == "All") {
                    "Default"
                } else {
                    parent.getItemAtPosition(position).toString()
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Handle case where nothing is selected
            }
        }

        // Keyword auto-populate behavior
        // https://chat.openai.com/c/b521afab-9950-4303-96ed-fc0cb9336c8e
        keyword.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            // Handle item selection here
            val selectedItem = keyword.adapter.getItem(position) as String
//            Toast.makeText(requireContext(), "Selected item: $selectedItem", Toast.LENGTH_SHORT).show()
        }

        keyword.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                // Not needed in this example
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

                if (s != null && s.isNotEmpty()) {
                    autoProgressBar.visibility = View.VISIBLE
                    searchKeyword(s.toString())
                }
            }

            override fun afterTextChanged(s: Editable?) {

            }
        })





        // Buttons
        view.findViewById<Button>(R.id.SearchButton)
            .setOnClickListener {

                if(keyword.text.isEmpty() || distField.text.isEmpty() || (!autoLocation.isChecked && locationField.text.isEmpty())) {
                    // required fields not valid
                    val contextView = view.findViewById<View>(R.id.searchFragment)
                    snackbar = Snackbar.make(contextView, "Please fill all fields", Snackbar.LENGTH_LONG)
                    snackbar.show()
                }
                else {
                    searchButton(view)
                }
            }

        view.findViewById<Button>(R.id.ClearButton)
            .setOnClickListener {
                clearButton(view)


            }




    }

    private fun searchKeyword(query: String) {
        val url = backend_url + "suggest?keyword=$query"
        val request = JsonObjectRequest(url, { response ->
            val searchResults = mutableListOf<String>()
            var list = response.optJSONObject("_embedded")?.optJSONArray("attractions")
            for (i in 0 until (list?.length() ?: 0)) {
                val item = list?.getJSONObject(i)

                val searchResult = item?.getString("name")
                if (searchResult != null) {
                    searchResults.add(searchResult)
                }
            }
            val textViewId = android.R.id.text1
            val adapter = object: ArrayAdapter<String>(requireContext(), android.R.layout.simple_dropdown_item_1line, searchResults) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val view = super.getView(position, convertView, parent)
                    val textView = view.findViewById<TextView>(textViewId)
                    textView.setTextColor(Color.GREEN)
                    textView.setBackgroundColor(Color.BLACK)
                    return view
                }
            }

            keyword.setAdapter(adapter)
            autoProgressBar.visibility = View.GONE
            adapter.notifyDataSetChanged()
        }, { error ->
            Toast.makeText(requireContext(), "Search failed: ${error.message}", Toast.LENGTH_SHORT).show()
            autoProgressBar.visibility = View.GONE
        })
        requestQueue.add(request)
    }

    private fun showResults(v: View?) {
        val navController = findNavController()
        val bundle = bundleOf(
            "keyword" to keyword.text.toString(),
            "distance" to distField.text.toString(),
            "category" to selectedCat,
            "location" to locationField.text.toString(),
            "autoLocation" to autoLocation.isChecked
        )
        Log.v("bundle", bundle.toString())
        navController.navigate(R.id.action_search_to_searchResults, bundle)



    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // get bundle
        Log.v("bundle?",requireArguments().toString())
        keywordVal = requireArguments().getString("keywordVal", "")
        distVal = requireArguments().getString("distVal", DEFAULT_DISTANCE)
        catVal = requireArguments().getString("catVal", "Default")
        locVal = requireArguments().getString("locVal", "")
        autoLocVal = requireArguments().getBoolean("autoLocVal", false)
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        spinner.onItemSelectedListener = null
        autoLocation.setOnCheckedChangeListener(null)
    }



    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Search.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Search().apply {
                arguments = Bundle().apply {
                }
            }
    }

    private fun searchButton(view: View) {

        showResults(view)




    }
    private fun clearButton(view: View) {
        // Reset Search Form
        distField.setText(DEFAULT_DISTANCE);
        keyword.setText("")
        spinner.setSelection(0)
        autoLocation.isChecked = false
        locationField.setText("")
        autoProgressBar.visibility = View.GONE
        if(this::snackbar.isInitialized && snackbar.isShown) { snackbar.dismiss()}
    }
}