package com.example.eventfinder

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.location.LocationRequest
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationResult
import com.google.android.gms.tasks.OnCompleteListener
import com.google.gson.JsonArray
import org.json.JSONArray


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

/**
 * A simple [Fragment] subclass.
 * Use the [SearchResults.newInstance] factory method to
 * create an instance of this fragment.
 */
class SearchResults : Fragment(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var adapter: ResultsAdapter
    private lateinit var requestQueue: RequestQueue
    private lateinit var noEventsCard: CardView
    private lateinit var resultsScroll: ScrollView
    private lateinit var searching: RelativeLayout
    private val backend_url = "http://hw8-env.eba-hwjhcppp.us-east-1.elasticbeanstalk.com/"
    var client: FusedLocationProviderClient? = null

    private lateinit var keyword: String
    private lateinit var distance: String
    private lateinit var cat: String
    private lateinit var loc: String
    var autoloc = false
    var lat = ""
    var long = ""
    var resultList = JSONArray()

    //Favorites
    private lateinit var sharedPreferences: SharedPreferences




    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<Button>(R.id.results_back_button)
            .setOnClickListener {
                val navController = findNavController()

                val bundle = bundleOf(
                    "keywordVal" to keyword,
                    "distVal" to distance,
                    "catVal" to cat,
                    "locVal" to loc,
                    "autoLocVal" to autoloc
                )
                navController.navigate(R.id.action_searchResults_to_search, bundle)

            }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestQueue = Volley.newRequestQueue(requireContext())
        sharedPreferences = requireActivity().getSharedPreferences("favorites",
            Context.MODE_PRIVATE);
//        sharedPreferences.edit().clear().commit();

        sharedPreferences.registerOnSharedPreferenceChangeListener(this)


    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // get bundle
        keyword = requireArguments().getString("keyword", "")
        distance = requireArguments().getString("distance", "10")
        cat = requireArguments().getString("category", "Default")
        loc = requireArguments().getString("location", "")
        autoloc = requireArguments().getBoolean("autoLocation", false)

        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_search_results, container, false)
        recyclerView = view.findViewById(R.id.searchResultsRecycler)
        progressBar = view.findViewById(R.id.searchResultsProgress)
        progressBar.visibility = View.VISIBLE
        noEventsCard = view.findViewById(R.id.no_events_found)
        noEventsCard.visibility = View.GONE
        resultsScroll = view.findViewById(R.id.results_scroll)
        resultsScroll.visibility = View.GONE
        searching = view.findViewById(R.id.searching)
        searching.visibility = View.VISIBLE

        // Initialize location client
//        client = LocationServices
//            .getFusedLocationProviderClient(
//                requireContext());

        // Set up the RecyclerView and its adapter
        Log.v("fragments", requireActivity().supportFragmentManager.fragments.toString())
        val faveFragment = requireActivity().supportFragmentManager.findFragmentByTag("f1") as Favorites?
        adapter = ResultsAdapter(requireActivity(), faveFragment)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter


        // Load data from server
        getSearchResults()

        return view
    }

    private fun getCurrentLocation() {
        // Initialize Location manager
        val locationManager = requireContext().getSystemService(
                Context.LOCATION_SERVICE
            ) as LocationManager
        // Check condition
        if (locationManager.isProviderEnabled(
                LocationManager.GPS_PROVIDER
            )
            || locationManager.isProviderEnabled(
                LocationManager.NETWORK_PROVIDER
            )
        ) {
            // When location service is enabled
            // Get last location
            if (ActivityCompat.checkSelfPermission(
                    requireContext(),
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    requireContext(),
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return
            }
            client!!.lastLocation.addOnCompleteListener(
                OnCompleteListener<Location> { task ->
                    // Initialize location
                    val location: Location? = task.result
                    // Check condition
                    if (location != null) {
                        // When location result is not
                        // null set latitude
                        Log.v("loc", location.latitude.toString())
                        // set longitude

                    } else {
                        // When location result is null
                        // initialize location request
                        val locationRequest: com.google.android.gms.location.LocationRequest? = com.google.android.gms.location.LocationRequest()
                            .setPriority(
                                LocationRequest.QUALITY_HIGH_ACCURACY
                            )
                            .setInterval(10000)
                            .setFastestInterval(
                                1000
                            )
                            .setNumUpdates(1)

                        // Initialize location call back
                        val locationCallback: LocationCallback = object : LocationCallback() {
                            override fun onLocationResult(
                                locationResult: LocationResult
                            ) {
                                // Initialize
                                // location
                                val location1: Location? = locationResult
                                    .lastLocation
                                // Set latitude
                                if (location != null) {
                                    Log.v("loc", location.latitude.toString())
                                }
                                // Set longitude

                            }
                        }

                        // Request location updates
                        if (locationRequest != null) {
                            client!!.requestLocationUpdates(
                                locationRequest,
                                locationCallback,
                                Looper.myLooper()
                            )
                        }
                    }
                })
        } else {
            // When location service is not enabled
            // open location setting

        }
    }

    private fun getSearchResults() {
        progressBar.visibility = View.VISIBLE
        // Perform network request in a background thread
        // Once the data has been loaded, update the adapter and hide the progress bar
        // Check if location permissions are granted
        if(autoloc) {
            getIPinfo()
        }
        else {
            callEventSearchServer()
        }


    }

    private fun getIPinfo() {
        val token = "2ffb14ed222be7";
        val request = JsonObjectRequest("https://ipinfo.io/?token=$token",
            { response ->
                Log.v("ip",response.toString())
                var loc = response.getString("loc")
                var list = loc.split(",")
                if(list.isNotEmpty()) {
                    lat = list[0]
                    long = list[1]
                }
                callEventSearchServer()

            },
            { error ->
                Toast.makeText(requireContext(), "IPinfo failed: ${error.message}", Toast.LENGTH_SHORT).show()
            })
        requestQueue.add(request)
    }

    private fun callEventSearchServer() {
        val params = "keyword=$keyword&distance=$distance&category=$cat&location=$loc&autoLocation=$autoloc&eventId=&lat=$lat&long=$long"
        val url = backend_url + "searchEvents?" + params
        val request = JsonObjectRequest(url,
            { response ->
                Log.v("result", response.toString())
                //handle no results
                if(response.getJSONObject("page").getInt("totalElements") == 0) {
                    resultsScroll.visibility = View.GONE
                    searching.visibility = View.VISIBLE
                    noEventsCard.visibility = View.VISIBLE

                }
                else {
                    // handle events list
                    val searchResults = mutableListOf<String>()
                    var list = response.getJSONObject("_embedded").getJSONArray("events")
                    resultList = list
                    adapter.setData(list!!, sharedPreferences)
                    resultsScroll.visibility = View.VISIBLE
                    searching.visibility = View.GONE


                }

                progressBar.visibility = View.GONE

            },
            { error ->
                progressBar.visibility = View.GONE
                resultsScroll.visibility = View.GONE
                noEventsCard.visibility = View.VISIBLE
                searching.visibility = View.VISIBLE
                Toast.makeText(requireContext(), "Search failed: ${error.message}", Toast.LENGTH_SHORT).show()
            })
        requestQueue.add(request)

    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences, key: String) {
        Log.v("in listener","")
        adapter.notifyDataSetChanged()

    }

    fun refreshAdapter() {
        Log.v("in refresh adapter","")
        sharedPreferences = requireActivity().getSharedPreferences("favorites",
            Context.MODE_PRIVATE);
        adapter.setData(resultList, sharedPreferences)

    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment searchResults.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            SearchResults().apply {
                arguments = Bundle().apply {
                }
            }
    }
}