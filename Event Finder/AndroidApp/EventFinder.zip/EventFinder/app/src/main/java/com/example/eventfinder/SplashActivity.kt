package com.example.eventfinder

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_EventFinder_NoActionBar)
        super.onCreate(savedInstanceState)


        setContentView(R.layout.activity_splash)

        scheduleSplashScreen()

    }

    private fun scheduleSplashScreen() {
        val splashScreenDuration = getSplashScreenDuration()
        Handler().postDelayed(
            {
                // After the splash screen duration, route to the right activities
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            },
            splashScreenDuration
        )
    }

    private fun getSplashScreenDuration() = 1000L

    private fun routeToAppropriatePage() {
        // Example routing
        when {
//            MainActivity.start(this)
        }
    }
}