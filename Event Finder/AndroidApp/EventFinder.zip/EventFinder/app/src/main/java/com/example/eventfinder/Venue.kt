package com.example.eventfinder

import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.cardview.widget.CardView
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.squareup.picasso.Picasso
import java.text.SimpleDateFormat
import java.util.*


class Venue : Fragment(), OnMapReadyCallback {
    private lateinit var venueId: String

    private lateinit var loading: RelativeLayout
    private lateinit var results: ScrollView
    // Fields
    private lateinit var venueName: TextView
    private lateinit var venueAddress: TextView
    private lateinit var venueCityState: TextView
    private lateinit var venueContact: TextView
    private lateinit var openHours: TextView
    private lateinit var generalRule: TextView
    private lateinit var childRule: TextView

    private lateinit var venueLoc: LatLng
    private lateinit var map: GoogleMap

    private lateinit var requestQueue: RequestQueue
    private val backend_url = "http://hw8-env.eba-hwjhcppp.us-east-1.elasticbeanstalk.com/"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestQueue = Volley.newRequestQueue(requireContext())
        val mapFragment = childFragmentManager.findFragmentById(R.id.map_fragment) as? SupportMapFragment
        mapFragment?.getMapAsync(this)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // get bundle
        venueId = requireArguments().getString("venueId", "")
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_venue, container, false)

        loading = view.findViewById(R.id.loadingDetails)
        loading.visibility = View.VISIBLE
        results = view.findViewById(R.id.venueLayout)
        results.visibility = View.GONE

        // Fields
        venueName = view.findViewById(R.id.venueName)
        venueAddress = view.findViewById(R.id.venueAddress)
        venueCityState = view.findViewById(R.id.cityState)
        venueContact = view.findViewById(R.id.contactInfo)
        openHours = view.findViewById(R.id.openHours)
        generalRule = view.findViewById(R.id.generalRules)
        childRule = view.findViewById(R.id.childRules)

        // Load data from server
        getVenueDetails()


        return view
    }

    private fun getVenueDetails() {
        // Perform network request in a background thread
        // Once the data has been loaded, update the adapter and hide the progress bar
        // Check if location permissions are granted
        val params = "venue=$venueId"
        val url = backend_url + "searchVenue?" + params
        val request = JsonObjectRequest(url,
            { response ->
                Log.v("result", response.toString())
                loading.visibility = View.GONE
                results.visibility = View.VISIBLE
                //handle results
                venueName.text = response.getString("name")
                venueName.isSelected = true

                venueAddress.text = response.getJSONObject("address").getString("line1")
                venueAddress.isSelected = true

                venueCityState.text = "${response.getJSONObject("city").getString("name")}, ${response.getJSONObject("state").getString("name")}"
                venueCityState.isSelected = true

                venueContact.text = response.optJSONObject("boxOfficeInfo")?.optString("phoneNumberDetail")
                if(venueContact.text == "") {
                    venueContact.visibility = View.GONE
                }
                venueContact.isSelected = true

                openHours.text = response.optJSONObject("boxOfficeInfo")?.optString("openHoursDetail")
                if(openHours.text == null || openHours.text == "") {
                    (view?.findViewById(R.id.openHoursLabel) as TextView).visibility = View.GONE
                }
                openHours.setOnClickListener {
                    // Do something when the text view is clicked
                    onTextViewClick(openHours)
                }

                generalRule.text = response.optJSONObject("generalInfo")?.optString("generalRule")
                if(generalRule.text == null || generalRule.text == "") {
                    (view?.findViewById(R.id.generalRulesLabel) as TextView).visibility = View.GONE
                }
                generalRule.setOnClickListener {
                    // Do something when the text view is clicked
                    onTextViewClick(generalRule)
                }

                childRule.text = response.optJSONObject("generalInfo")?.optString("childRule")
                if(childRule.text == null || childRule.text == "") {
                    (view?.findViewById(R.id.childRulesLabel) as TextView).visibility = View.GONE
                }
                childRule.setOnClickListener {
                    // Do something when the text view is clicked
                    onTextViewClick(childRule)
                }

                if((childRule.text == null || childRule.text == "") && (generalRule.text == null || generalRule.text == "") && (openHours.text == null || openHours.text == "") ) {
                    (view?.findViewById(R.id.extraInfoCard) as CardView).visibility = View.GONE
                }

                venueLoc = LatLng(response.getJSONObject("location").getString("latitude").toDouble(), response.getJSONObject("location").getString("longitude").toDouble())

                val mapFragment = childFragmentManager.findFragmentById(R.id.map_fragment) as SupportMapFragment
                mapFragment.getMapAsync(this)







            },
            { error ->
                loading.visibility = View.GONE
                results.visibility = View.VISIBLE
                Toast.makeText(requireContext(), "Search failed: ${error.message}", Toast.LENGTH_SHORT).show()
            })
        requestQueue.add(request)


    }



    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

//        val mapFragment = childFragmentManager.findFragmentById(R.id.map_fragment) as SupportMapFragment
//        mapFragment.getMapAsync(this)
    }

    private fun onTextViewClick(view: TextView) {
        if(view.ellipsize == null) {
            view.ellipsize = TextUtils.TruncateAt.END
            view.maxLines = 3
        }
        else {
            view.ellipsize  = null
            view.maxLines = Int.MAX_VALUE
        }

    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        addVenueMarker()

//        val markerOptions = MarkerOptions().position(LatLng(37.7749, -122.4194)).title("San Francisco")
//        map.addMarker(markerOptions)
    }

    private fun addVenueMarker() {
        val markerPosition = venueLoc
        val markerOptions = MarkerOptions().position(markerPosition)
        markerOptions.title(venueName.text.toString())
        map.addMarker(markerOptions)
        val zoomLevel = 15.0f
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(venueLoc, zoomLevel))
    }
}